#' @export
compute_gmv <- function(x) UseMethod("compute_gmv")


#' @export
do_nothing <- function(x) TRUE

#' @export
long <- function(x) UseMethod("long")


#' @export
short <- function(x) UseMethod("short")

#' Computes performance of a strategy object
#'
#' All strategy dates must be contained in the returns dates.
#' The performance of the strategy is comprised of pnl, turnover
#' and the time series of the strategy.
#'
#' @param PORT list, holdings of strategy (one element per date)
#' @param RETS matrix of returns
#' @param shortfall numeric, market impact in bps
#' @param borrowrate numeric, borrow rate in bps
#' @return vector of pnl
#' 
#' @export
.compute_performance <- function(PORT, RETS, shortfall=0, borrow=0, keep_strategy=FALSE){
  stopifnot(all(names(PORT) %in% row.names(RETS)))
  dtes_start <- min(names(PORT))
  dtes_end   <- max(row.names(RETS))
  ids <- PORT %>% lapply(names) %>% Reduce(union, .)
  R <- filter(RETS, date >= dtes_start, id %in% ids)
  dtes <- row.names(R)
  pnl <- structure(rep(NA, nrow(R)), names=dtes)
  work_portfolio <- list()  
  work_portfolio[[dtes_start]] <- PORT[[dtes_start]]

  turnover <- structure(rep(0, nrow(R)), names=dtes)
  for (d in dtes){
    v <- R[d, ] + 1
    v[is.na(v)] <- 1
    if (d %in% names(PORT)) {  
      tmp_portfolio <- opVectors(work_portfolio[[d]], v, FUN=`*`)
      scaling_factor <- ifelse(d > dtes_start, sum(abs(tmp_portfolio))/sum(abs(PORT[[d]])), 1)
      work_portfolio[[d]] <- scaling_factor * PORT[[d]]
      turnover[d] <- sum(abs(opVectors(work_portfolio[[d]], tmp_portfolio, FUN=`-`))) / sum(abs(tmp_portfolio))
    }
    pnl[d] <- opVectors(work_portfolio[[d]], R[d, ], FUN = `*`) %>% sum(na.rm=TRUE)
    if (is.na(pnl[d])) stop('missing dates')
    if (d < dtes_end){
      d_next <- succ(d, dtes)
      v <- R[d, ] + 1
      v[is.na(v)] <- 1
      work_portfolio[[d_next]] <- opVectors(work_portfolio[[d]], v, FUN=`*`)
    }
  }
  # creates adjusted pnl. I am using an approximate number of trading days in 
  # order to avoid dependencies on date libraries
  days_trading <- 252/365*as.numeric(as.Date(first(dtes))-as.Date(last(dtes)))
  portfolio_gmv <- sapply(work_portfolio, function(x) sum(abs(x)))
  portfolio_shortnmv <- sapply(work_portfolio, function(x) -sum(pmin(x,0)))
  turnover_costs <- shortfall*sum(turnover)*portfolio_gmv/days_trading
  borrow_costs <- portfolio_shortnmv*borrow
  pnl_adj <- pnl - borrow_costs - turnover_costs
  class(work_portfolio) <- c('strategy', 'list')
  if (!keep_strategy) work_portfolio <- NULL
  list(ret = pnl/portfolio_gmv, 
       ret_adj = pnl_adj/portfolio_gmv, 
       turnover = turnover, 
       strategy = work_portfolio)
}


#' Converts a list of vectors, a data frame or a matrix into a strategy 
#' object.
#'
#' If input is a list, it must be comprised of numeric vector elements. 
#' The names of the elements are date characters of format "YYYY-MM-DD", 
#' and the names of the vectors are asset ids.
#' If input is a data frame, it must have three columns: date, asset id, 
#' weight. The data frame names need not be 'date', 'asset', 'id'.
#' If input is a matrix, it must have row.names equal to dates, and colnames 
#' equal to asset ids.
#'
#' @param x a list, a matrix or a data frame
#' @return a strategy object 
#' @examples
#' PORT1 <- list(`2000-01-01`=structure(1:20, names=letters[1:20]),
#' `2001-01-01`=structure((-1)^(1:10), names=letters[1:10]))
#' PORT2 <- list(`2000-01-01`=structure(1:20, names=letters[7:26]),
#' `2001-01-01`=structure(sin(1:10), names=letters[11:20]))
#' x <- as.strategy(PORT1)
#' @export
#' 
as.strategy <- function(x) UseMethod('as.strategy')

#' converts a strategy to a strategy (identity)
#' 
#' @param x strategy
#' @export
as.strategy.list <- function(x){
  class(x) <- c('strategy', 'list')
  x
}

#' converts a list to a strategy
#' 
#' @param x list of vectors
#' @export
as.strategy.strategy <- function(x) x  

#' Convert a matrix to a strategy
#' 
#' @param x matrix
#' @export
as.strategy.matrix <- function(x) x %>% m2l %>% lapply(function(x) x[!is.na(x)]) %>% as.strategy

#' Convert a data frame to a strategy
#'
#' @param x data frame
#' @export
as.strategy.data.frame <- function(x) {
  names(x) <- c('date','asset','value')
  y <- dlply(x, .(date), function(x) structure(x$value, names=x$asset)) %>% as.strategy
  attr(y, 'split_type') <- NULL
  attr(y, 'split_labels') <- NULL

  y
}

#' Converts list, data.frame, matrix to a set of strategies object.
#'
#' @param ..., objects, either:
#'   lists of numeric vectors, with element names of the form 'YYYY-MM-DD';
#'   data.frame with rows of the form 'YYYY-MM-DD', asset identifier, numeric value;
#'   matrix, with row.names of the form 'YYYY-MM-DD' and colnames asset identifiers.
#' @return a sos object
#' @examples
#' PORT1 <- list(`2000-01-01`=structure(1:20, names=letters[1:20]),
#' `2001-01-01`=structure((-1)^(1:10), names=letters[1:10]))
#' PORT2 <- list(`2000-01-01`=structure(1:20, names=letters[7:26]),
#' `2001-01-01`=structure(sin(1:10), names=letters[11:20]))
#' x <- as.sos(p1=PORT1, p2=PORT2)
#' x2 <- as.sos(PORT1, PORT2) # names are inferred to be PORT1, PORT2
#' x3 <- as.sos(PORT1 + PORT2) # should give a warning
#' @export
#' 
as.sos <- function(...){
  X <- list(...)
  Y <- lapply(X, as.strategy)
#   names(Y) <- X_names
  class(Y) <- c('sos','list')
  Y
}


#' summarizes a set of strategies
#'
#' @param sos object
#' @return a data frame with strategy name, first date, last date, n.dates, min no.assets, max no.assets, avg no.assets
#' @export
#' 
summary.sos <- function(data){
  lapply(data, summary) %>% do.call(rbind,.)
}

#' summarizes a strategy
#'
#' @param strategy object
#' @return a data frame with strategy name, first date, last date, n.dates, min no.assets, max no.assets, avg no.assets
#' @export
#' 
summary.strategy <- function(data){
  num_assets <- sapply(data, length)
  data.frame(
    start         = min(names(data)), 
    end           = max(names(data)), 
    no.dates      = length(data), 
    min.no.assets = min(num_assets),
    max.no.assets = max(num_assets),
    avg.no.assets = mean(num_assets)
  )
}

# 
# 
# .capture_dot_names <- function(...){
#   X_names <- match.call() 
#   X_names %<>% as.character %>% {.[-1]} 
#   if ( any(sapply(X_names, length) > 1)){
#     warning('At least one name is composite')
#     X_names %<>% sapply(paste0, collapse='')
#   }
#   X_names %>% ifelse(names(.) == "", ., names(.)) 
# }


#' Add one or more portfolios, as separate arguments, to a set-of-portfolios (sos) object.
#'
#' @param data set of strategies (sos) object
#' @param ..., objects, either:
#'   lists of numeric vectors, with element names of the form 'YYYY-MM-DD';
#'   data.frame with rows of the form 'YYYY-MM-DD', asset identifier, numeric value;
#'   matrix, with row.names of the form 'YYYY-MM-DD' and colnames asset identifiers.
#' @return a sos object
#' @export
#' 
add_strategy_all <- function(data, ...){
  dot_class <- class(list(...)[[1]])
  if (length(list(...)) == 1 & length(dot_class) == 1 & dot_class[1] == 'list') {
    stop('Use add_strategy_all list when adding a list of sos objects')
  }
  add_strategy_list(a, list(...))
}

#' Add one or more portfolios, wrapped into a list, to a set-of-portfolios (sos)
#' object.
#'
#' @param data set of strategies (sos) object
#' @param X, a list of objects, either:
#'   lists of numeric vectors, with element names of the form 'YYYY-MM-DD';
#'   data.frame with rows of the form 'YYYY-MM-DD', asset identifier, numeric 
#'   value; matrix, with row.names of the form 'YYYY-MM-DD' and colnames asset 
#'   identifiers.
#' @return a sos object
#' @export
#' 
add_strategy_list <- function(data, X){
  stopifnot(all(names(X) != ''))
  Y <- lapply(X, as.strategy)
  for (n in names(Y)){
    data[[n]] <- Y[[n]]
  }
  data
}


#' compute pnl for a set of strategies
#'
#' @param X set of strategies
#' @param RETS matrix of returns
#' @return list of performance objects
#'
#' @export
#' 
backtest <- function(X, RETS, shortfall=0, borrow=0){
  X <- lapply(X, .compute_performance, RETS=RETS, shortfall=shortfall, borrow=borrow)
  ret      <- lapply(X, '[[', 'ret')      %>% do.call(cbind, .)
  ret_adj  <- lapply(X, '[[', 'ret_adj')  %>% do.call(cbind, .)
  turnover <- lapply(X, '[[', 'turnover') %>% do.call(cbind, .)
  list(ret = ret, ret_adj=ret_adj, turnover = turnover)
}


#' compute gmv for a set of strategies
#'
#' @param X set of strategies
#' @param RETS matrix of returns
#' @return list of pnl
#'
#' @export
#' 
compute_gmv.sos <- function(X, RETS){
  lapply(X, compute_gmv, RETS=RETS)
}

#compute returns for a strategy
#' @export
#' 
compute_turnover.sos <- function(X){
  lapply(X, compute_turnover)
}


binary_op_strategy <- function(x, y, op){
  #   browser()
  if ('strategy' %in% class(x) & 'strategy' %in% class(y)){
    common_names <- intersect(names(x), names(y))
    out <- .lapply(common_names, function(n) opVectors(x[[n]], y[[n]], FUN=op, all=TRUE))
  } else if ('strategy' %in% class(x) & 'numeric' %in% class(y) & length(y)==1){
    out <- lapply(x, function(v) op(v, y))
  } else if ('strategy' %in% class(y) & 'numeric' %in% class(x) & length(x)==1){
    out <- lapply(y, function(v) op(x,v))
  } else {
    stop('Invalid argument.')
  }
  class(out) <- c('strategy', 'list')
  out
}

#' Sums two strategy objects
#' 
#' @param x strategy
#' @param y strategy
#' @return strategy 
#' 
#' @export
#' 
`+.strategy` <- function(x, y){
  binary_op_strategy(x, y, `+`)
}

#' Subtracts two portfolios
#' 
#' @param x strategy
#' @param y strategy
#' @return strategy 
#' 
#' @export
#' 
`-.strategy` <- function(x, y){
  binary_op_strategy(x, y, `-`)
}

#' Multiplies two portfolios, or a strategy and a scalar
#' 
#' @param x strategy or numeric
#' @param y strategy or numeric
#' @return strategy 
#' 
#' @export
#' 
`*.strategy` <- function(x, y){
  binary_op_strategy(x, y, `*`)
}

#' Divides two portfolios, or a strategy by a scalar or a scalar by a 
#' strategy
#' 
#' @param x strategy
#' @param y strategy
#' @return strategy 
#' 
#' @export
#' 
`/.strategy` <- function(x, y){
  binary_op_strategy(x, y, `/`)
}


#' apply trunc() to a strategy's holdings. 
#' 
#' @param x strategy 
#' @return strategy 
#' 
#' @export
#'   
`trunc.strategy` <- function(x){
  out <- .lapply(names(x), function(n) trunc(x[[n]]))
}

#' apply ceiling() to a strategy's holdings. 
#' 
#' @param x strategy 
#' @return strategy 
#' 
#' @export
#'   
`ceiling.strategy` <- function(x){
  out <- .lapply(names(x), function(n) ceiling(x[[n]]))
}

#' apply round() to a strategy's holdings. 
#' 
#' @param x strategy 
#' @param digits integer
#' @return strategy 
#' 
#' @export
#'   
`round.strategy` <- function(x, digits = 0){
  out <- .lapply(names(x), function(n) round(x[[n]], digits))
}


#' Longs of a strategy's holdings. 
#' 
#' @param x strategy 
#' @return strategy 
#' 
#' @export
#'   
long.strategy <- function(.data){
  y <- lapply(.data, function(x) x[x>0] )
  class(y) <- c('strategy', 'list')
  y
}

#' Longs of a strategy's holdings. 
#' 
#' @param x strategy 
#' @return strategy 
#' 
#' @export
#'   
short.strategy <- function(.data){
  y <- lapply(.data, function(x) x[x<0] )
  class(y) <- c('strategy', 'list')
  y
}



#' Shorts of a strategy's holdings. 
#' 
#' @param x strategy 
#' @return strategy 
#' 
#' @export
#'   
long.strategy <- function(.data){
  y <- lapply(.data, function(x) x[x<0] )
  class(y) <- c('strategy', 'list')
  y
}

#' Dollar-neutral version of a strategy 
#' 
#' @param x strategy 
#' @param bench_id character, identifier of the benchmark
#' @return strategy 
#' 
#' @export
#'   
dollar_neutral.strategy <- function(.data, bench_id){
  y <- lapply(.data, function(x) { 
    x <- c(x, -sum(x))
    names(x)[length(x)] <- bench_id
    x
  })
  class(y) <- c('strategy', 'list')
  y
}

#' Beta-neutral version of a strategy 
#' 
#' @param x strategy 
#' @param BETA matrix of the betas of the assets (dates/assets)
#' @param bench_id character, identifier of the benchmark
#' @return strategy 
#' 
#' @export
#'   
beta_neutral.strategy <- function(.data, BETA, bench_id){
  .data <- l2m(.data)
  .data[is.na(.data)] <- 0
  stopifnot(all(row.names(.data) %in% row.names(BETA)))
  betas <- align_array(.data, BETA, all=c(F,F)) %>% apply(1,sum)
  .data <- cbind(.data, -betas)
  colnames(.data)[ncol(.data)] <- bench_id
  y <- m2l(.data, by.row=TRUE) %>% lapply(function(x) x[!is.na(x)])
  class(y) <- c('strategy', 'list')
  y
}


#' Adds portfolios to a sos objects (safe hatch)
#' 
#' @param data a set of strategies (sos) object
#' @param .... expressions
#' @return a sos object
#' @export
#' 
mutate_.sos <- function(.data, .dots){
  #   dots <- lazyeval::all_dots(.dots, ..., all_named = TRUE)
  X <- lazy_eval(.dots, .data)
  add_strategy_list(.data, X)
}


#' Filter portfolios in a sos object by date (safe hatch)
#' 
#' @param data a set of strategies (sos) object
#' @param ... expressions using the variable date, returning a boolean
#' 
#' @export
#' 
filter_.sos <- function(.data, .dots){
  X <- lapply(.data, function(x){
    tmp <- data.frame(date=names(x), stringsAsFactors=FALSE)
    ind <- lazy_eval(.dots, tmp)[[1]]
    x[ind]
  })
  X
}

#' Selects portfolios in a sos object (safe hatch)
#' 
#' @param data a set of strategies (sos) object
#' @param ... names of the portfolios
#' 
#' @export
#' 
get_strat <- function(.data, ...){
  .dots <- c(...)
  .data[.dots]
}


#' Make a summary report table
#' 
#' @param data matrix, returns (or adjusted returns) arranged by date/assets (rows/asset ids)
#' @param ... functions operating of a time series of returns
#' 
#' @export
#' 
make_report_list <- function(data, ...){
  fn_list <- list(...)
  make_report_all(data, fn_list)
}

  
#' Make a summary report table
#' 
#' @param data matrix, returns (or adjusted returns) arranged by date/assets (rows/asset ids)
#' 
#' 
#' @param fn_list, list of functions operating of a time series of returns
#' 
#' @export
#' 
make_report_all <- function(data, fn_list){
  S <- data.frame(strategy=colnames(data))
  lapply(fn_list, function(fn) adply(data, 2, fn) %>% select(-X1))  %>%
    bind_cols %>% 
    {cbind(S,.)}
}


#' Computes maximum drawdown
#' @param x numeric vector, returns
#' @return a data frame containing drawdown, its start
#' and end dates
#' @export
compute_drawdown <- function(x){
  # x is a time series of returns
  x_len <- length(x)
  max_drawdown <- 0 
  drawdown_startdate <- ''
  drawdown_enddate <- ''
  for (n in seq(x)){
    x2 <- 1+x[n:x_len]
    x_cumret <- cumprod(x2)
    x_min <- min(x_cumret)
    temp_drawdown <- x_min - 1
    if (temp_drawdown < max_drawdown){
      max_drawdown <- temp_drawdown
      drawdown_startdate <- names(x)[n]
      drawdown_enddate <- names(x2)[x_cumret == x_min][1]
    }
  }
  if (max_drawdown == 0) {
    maxdrawdown <- 0
    drawdown_startdate <- NA_character_
    drawdown_enddate <- NA_character_ 
  }
  out <- data.frame(maxdrawdown=max_drawdown, 
             start.date=drawdown_startdate, 
             end.date=drawdown_enddate, 
             stringsAsFactors = FALSE)  
  row.names(out) <- NULL
  out
}

#' computes Sharpe Ratio for a set of returns, assuming iid returns
#'
#' @param r numeric, returns
#' @param period numeric, average interval between return data
#' @param volAdjPeriod integer or NULL, if integer the returns are normalized
#' by vol estimates of window volAdjPeriod centered at the return
#' @author G.A.Paleologo 
#' @return numeric, sharpe ratio computed as mean(r)/sd(r)*sqrt(period)
#' @export
compute_sharpe <- function(r, period=1, volAdjPeriod=NULL){
  if (!is.null(volAdjPeriod)){
    r <- zoo(r, as.Date(names(r)))
    r <- rollapply(r, volAdjPeriod, function(x) 
      x[floor(length(x))/2]/sd(x, na.rm=T), align='center')
  }
  SR <- (mean(r, na.rm=TRUE) / sd(r, na.rm=TRUE) * sqrt(252/period)) %>% round(2)
  data.frame(Sharpe=SR, row.names=NULL)
}


#' computes alphas and betas of a strategy with respect to a benchmark
#'
#' @param rets numeric, returns
#' @param benchmark numeric, time series of benchmarks
#' @param country character, country
#' @return data frame, alpha and beta of the strategy
#' @export
compute_alphabeta <- function(rets, benchmark, country){
  benchmark %<>% v2df(c('date', 'benchmark'))
  rets %<>% v2df(c('date','ret'))
  A <- left_join(rets, benchmark, by='date') %>%
    dplyr::arrange(desc(date)) 
  stopifnot(all(!is.na(A)))

  numdays <- numTD(min(A$date), max(A$date), country=country)
  period <- numdays / nrow(rets)
  tmp <- lm(ret ~ benchmark, data=A)$coefficients
  data.frame(alpha = round(tmp[1]*252/period*100,2), beta = round(tmp[2], 2), row.names=FALSE)
}


