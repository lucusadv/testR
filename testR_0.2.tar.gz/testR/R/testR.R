#' mplyr: Library for matrix manipulation 
#'    
#' @import  gridExtra ggplot2 plyr dplyr magrittr scales lazyeval reshape2 Gmisc
#' @docType package
#' @name testR
#' @author G.A.Paleologo 
NULL
